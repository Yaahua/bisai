import json
from pathlib import Path
from collections import Counter, defaultdict

ROOT = Path('/home/ubuntu/bisai')
train_path = ROOT/'数据/官方原始数据/train.json'
v44_path = ROOT/'数据/A榜/submit_v44_del_var_con_cross.json'
versions = {
    'v36_gene_abs': ROOT/'数据/A榜/submit_v36_gene_abs.json',
    'v41_sub_conservative': ROOT/'数据/A榜/submit_v41_sub_conservative.json',
    'v44_del_var_con_cross': v44_path,
    'v45_del_gene_loi_mrk': ROOT/'数据/A榜/submit_v45_del_gene_loi_mrk.json',
    'v45_fix_gene_mrk_direction': ROOT/'数据/A榜/submit_v45_fix_gene_mrk_direction.json',
    'v45_del_low_freq_types': ROOT/'数据/A榜/submit_v45_del_low_freq_types.json',
}

def load(p):
    return json.loads(p.read_text(encoding='utf-8'))

def rel_type(r):
    return f"{r.get('head_type')}-{r.get('label')}-{r.get('tail_type')}"

def rel_key(idx, r):
    return (
        idx, r.get('head'), r.get('head_start'), r.get('head_end'), r.get('head_type'),
        r.get('label'), r.get('tail'), r.get('tail_start'), r.get('tail_end'), r.get('tail_type')
    )

def inv_type(t):
    a, lab, b = t.split('-')
    return f"{b}-{lab}-{a}"

def extract_rels(data):
    rows=[]
    for i, item in enumerate(data):
        for r in item.get('relations', []):
            rows.append((i, r, rel_type(r)))
    return rows

train = load(train_path)
v44 = load(v44_path)
train_rows = extract_rels(train)
v44_rows = extract_rels(v44)
train_type = Counter(t for _,_,t in train_rows)
v44_type = Counter(t for _,_,t in v44_rows)

# reverse asymmetry table for types appearing in v44 or train
all_types = sorted(set(train_type)|set(v44_type))
rev_rows=[]
for t in all_types:
    rt = inv_type(t)
    if t <= rt:  # avoid duplicate pair tables? still include unpaired later
        rev_rows.append({
            'type': t,
            'reverse': rt,
            'train': train_type[t],
            'train_reverse': train_type[rt],
            'v44': v44_type[t],
            'v44_reverse': v44_type[rt],
            'train_ratio': (train_type[t]+1)/(train_type[rt]+1),
            'v44_ratio': (v44_type[t]+1)/(v44_type[rt]+1),
        })
rev_rows.sort(key=lambda x: max(x['v44'], x['v44_reverse']) + max(x['train'], x['train_reverse']), reverse=True)

# stability score across known high-score versions
version_sets = {}
for name,p in versions.items():
    if p.exists():
        data=load(p)
        version_sets[name]=set(rel_key(i,r) for i,item in enumerate(data) for r in item.get('relations', []))

base_keys = version_sets.get('v44_del_var_con_cross', set())
stability=[]
for i,r,t in v44_rows:
    key=rel_key(i,r)
    present=sum(key in s for s in version_sets.values())
    stability.append((present, i, t, r))
stability.sort(key=lambda x: (x[0], x[1], x[2], str(x[3].get('head')), str(x[3].get('tail'))))

# academic experiment recommendations based on evidence
low_freq = []
for t,c in sorted(v44_type.items(), key=lambda x:(train_type[x[0]], x[1], x[0])):
    if train_type[t] <= 5:
        low_freq.append((t,c,train_type[t], v44_type[inv_type(t)], train_type[inv_type(t)]))

# sample clusters for low freq
cluster=defaultdict(list)
for i,r,t in v44_rows:
    if train_type[t] <= 5:
        cluster[(i,t)].append(r)
cluster_rows=sorted(((len(v),i,t,v) for (i,t),v in cluster.items()), reverse=True)[:25]

out=[]
out.append('# 学术方法到 bisai 仓库的实验映射\n')
out.append('## 1. 方向混淆矩阵 Top 项\n')
out.append('|类型|反向类型|训练数|反向训练数|v44数|v44反向数|判断|')
out.append('|---|---|---:|---:|---:|---:|---|')
for row in rev_rows[:40]:
    judgement=''
    if row['v44']>0 and row['train']<=2 and row['train_reverse']>=10:
        judgement='v44 存在但训练反向更强，优先做方向验证'
    elif row['v44']>0 and row['train']==0:
        judgement='训练未见，需外部证据或单点消融'
    elif row['v44']>0 and row['train']>=10:
        judgement='方向较稳定，谨慎删除'
    out.append(f"|{row['type']}|{row['reverse']}|{row['train']}|{row['train_reverse']}|{row['v44']}|{row['v44_reverse']}|{judgement}|")

out.append('\n## 2. v44 低频关系与反向证据\n')
out.append('|类型|v44数|训练频次|v44反向数|训练反向频次|建议|')
out.append('|---|---:|---:|---:|---:|---|')
for t,c,tc,rv,rtc in low_freq:
    if tc<=2 and rtc>=10:
        advice='方向 QA 优先；先删后换成对提交'
    elif tc<=2:
        advice='单类型消融或样本簇消融'
    elif c<=1:
        advice='人工复核后保守处理'
    else:
        advice='暂不整包删除，按样本簇拆分'
    out.append(f"|{t}|{c}|{tc}|{rv}|{rtc}|{advice}|")

out.append('\n## 3. 低频样本簇 Top25\n')
out.append('|样本idx|类型|条数|关系摘要|实验建议|')
out.append('|---:|---|---:|---|---|')
for n,i,t,rels in cluster_rows:
    summaries=[]
    for r in rels[:4]:
        summaries.append(f"{r.get('head')}->{r.get('label')}->{r.get('tail')}")
    advice='样本簇删除候选' if n>=2 else '单条人工 QA 候选'
    out.append(f"|{i}|{t}|{n}|{' ; '.join(summaries).replace('|','/')}|{advice}|")

out.append('\n## 4. v44 中跨版本稳定性最低的关系 Top30\n')
out.append('|出现版本数|样本idx|类型|关系|建议|')
out.append('|---:|---:|---|---|---|')
for present,i,t,r in stability[:30]:
    rel=f"{r.get('head')}->{r.get('label')}->{r.get('tail')}".replace('|','/')
    suggestion='若低频/方向异常则优先复核；否则仅作为观察项'
    out.append(f"|{present}|{i}|{t}|{rel}|{suggestion}|")

out.append('\n## 5. v46/v47 原子实验队列\n')
out.append('|优先级|实验名|学术依据|修改对象|提交纪律|')
out.append('|---:|---|---|---|---|')
experiments=[
(1,'v46_direction_gene_loi_mrk_delete_vs_swap','Directionality + Entity-role QA','5 条 GENE-LOI-MRK 与 5 条 MRK-LOI-GENE 对照','先删后换，必须成对解释'),
(2,'v46_lowfreq_gene_con_trt_cluster372','Data-centric FP cleaning','样本 372 的 4 条 GENE-CON-TRT','只删一个样本簇'),
(3,'v46_lowfreq_qtl_aff_bis_cluster50','Data-centric FP cleaning','样本 50 的 3 条 QTL-AFF-BIS','只删一个样本簇'),
(4,'v46_llmqa_review_lowfreq_top20','QA + entity type markers','训练频次<=2且v44存在的关系','离线判别，不直接提交'),
(5,'v47_external_biorex_pubtator_evidence','Weak supervision + external evidence','基因/标记/性状类关系外部证据','只做证据排序'),
(6,'v47_stability_forgetting_subtract','Noisy label forgetting proxy','跨版本不稳定且低频关系','每次删除<=5条'),
(7,'v47_abs_aff_gene_micro_add','唯一历史有效加法的同源扩展','ABS-AFF-GENE 候选','每次新增<=3条且需 QA 证据'),
]
for row in experiments:
    out.append(f"|{row[0]}|`{row[1]}`|{row[2]}|{row[3]}|{row[4]}|")

Path('/home/ubuntu/bisai/分析报告/academic_to_experiment_mapping_20260430.md').write_text('\n'.join(out)+'\n', encoding='utf-8')
print('wrote mapping report')
print('train rels', len(train_rows), 'v44 rels', len(v44_rows), 'types', len(all_types))
