import json
import time
import requests
from pathlib import Path

queries = [
    "biomedical relation extraction BioRED data centric ensemble",
    "biomedical relation extraction directionality entity roles",
    "large language models biomedical information extraction relation extraction",
    "weak supervision biomedical relation extraction distant supervision",
    "entity relation extraction data centric post processing ensemble",
]

out_dir = Path('/home/ubuntu/bisai/分析报告/api_search_raw')
out_dir.mkdir(parents=True, exist_ok=True)
summary = []

headers = {"User-Agent": "bisai-research/1.0 (mailto:research@example.com)"}

def safe_get(url, params=None):
    try:
        r = requests.get(url, params=params, headers=headers, timeout=20)
        return {"status": r.status_code, "url": r.url, "json": r.json() if 'json' in r.headers.get('content-type','') else None, "text": r.text[:2000]}
    except Exception as e:
        return {"error": repr(e), "url": url, "params": params}

for q in queries:
    slug = ''.join(c if c.isalnum() else '_' for c in q.lower())[:80]
    # OpenAlex
    oa = safe_get('https://api.openalex.org/works', {"search": q, "per-page": 8})
    (out_dir / f'{slug}_openalex.json').write_text(json.dumps(oa, ensure_ascii=False, indent=2), encoding='utf-8')
    if oa.get('json'):
        for item in oa['json'].get('results', [])[:8]:
            summary.append({
                "source": "OpenAlex",
                "query": q,
                "title": item.get('title'),
                "year": item.get('publication_year'),
                "cited_by": item.get('cited_by_count'),
                "doi": item.get('doi'),
                "url": item.get('id'),
                "abstract_available": bool(item.get('abstract_inverted_index')),
            })
    time.sleep(1)
    # Crossref
    cr = safe_get('https://api.crossref.org/works', {"query": q, "rows": 8})
    (out_dir / f'{slug}_crossref.json').write_text(json.dumps(cr, ensure_ascii=False, indent=2), encoding='utf-8')
    if cr.get('json'):
        for item in cr['json'].get('message', {}).get('items', [])[:8]:
            summary.append({
                "source": "Crossref",
                "query": q,
                "title": (item.get('title') or [''])[0],
                "year": (item.get('published-print') or item.get('published-online') or item.get('created') or {}).get('date-parts', [[None]])[0][0],
                "cited_by": item.get('is-referenced-by-count'),
                "doi": item.get('DOI'),
                "url": item.get('URL'),
                "abstract_available": bool(item.get('abstract')),
            })
    time.sleep(1)
    # Semantic Scholar public API
    ss = safe_get('https://api.semanticscholar.org/graph/v1/paper/search', {
        "query": q,
        "limit": 8,
        "fields": "title,year,citationCount,url,abstract,externalIds,venue"
    })
    (out_dir / f'{slug}_semanticscholar.json').write_text(json.dumps(ss, ensure_ascii=False, indent=2), encoding='utf-8')
    if ss.get('json'):
        for item in ss['json'].get('data', [])[:8]:
            summary.append({
                "source": "SemanticScholar",
                "query": q,
                "title": item.get('title'),
                "year": item.get('year'),
                "cited_by": item.get('citationCount'),
                "doi": (item.get('externalIds') or {}).get('DOI'),
                "url": item.get('url'),
                "abstract_available": bool(item.get('abstract')),
            })
    time.sleep(1)

# de-duplicate by lower title
seen = set()
uniq = []
for row in sorted(summary, key=lambda x: (x.get('cited_by') or 0), reverse=True):
    key = (row.get('title') or '').lower().strip()
    if key and key not in seen:
        seen.add(key)
        uniq.append(row)

md = ['# 学术 API 广域检索结果摘要\n']
md.append('|序号|来源|年份|引用数|标题|DOI/URL|查询|')
md.append('|---:|---|---:|---:|---|---|---|')
for i, row in enumerate(uniq[:45], 1):
    link = row.get('doi') or row.get('url') or ''
    title = (row.get('title') or '').replace('|','/')
    query = row.get('query','').replace('|','/')
    md.append(f"|{i}|{row.get('source')}|{row.get('year') or ''}|{row.get('cited_by') or 0}|{title}|{link}|{query}|")

Path('/home/ubuntu/bisai/分析报告/academic_api_search_summary_20260430.md').write_text('\n'.join(md) + '\n', encoding='utf-8')
Path('/home/ubuntu/bisai/分析报告/academic_api_search_summary_20260430.json').write_text(json.dumps(uniq, ensure_ascii=False, indent=2), encoding='utf-8')
print(f'wrote {len(uniq)} unique records')
