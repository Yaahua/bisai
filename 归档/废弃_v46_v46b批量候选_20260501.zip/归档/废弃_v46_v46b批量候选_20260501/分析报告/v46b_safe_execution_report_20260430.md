# v46b 安全候选执行报告

第一个 v46 候选 `GENE-LOI-MRK` 删除版得分 0.4167，已强烈证伪整类删除假设。因此 v46b 明确排除所有 `GENE-LOI-MRK` 删除组合，改用 **单条微消融** 和 **历史保守共识微加法**。

## 1. 底座与约束

|项目|数值|
|---|---:|
|底座关系数|1052|
|底座样本数|400|
|禁用路径|`GENE-LOI-MRK` 删除及其任何组合|

## 2. 候选清单

|建议顺序|候选|关系变化|修改条数|校验错误|zip|假设|
|---:|---|---:|---:|---:|---|---|
|1|`submit_v46b_micro_del_372_01_gene_con_trt`|-1|1|0|`数据/A榜/v46b_safe/submit_v46b_micro_del_372_01_gene_con_trt.zip`|单条微消融：样本 372 的 GENE-CON-TRT，避免整簇删除不可归因。|
|2|`submit_v46b_micro_del_372_02_gene_con_trt`|-1|1|0|`数据/A榜/v46b_safe/submit_v46b_micro_del_372_02_gene_con_trt.zip`|单条微消融：样本 372 的 GENE-CON-TRT，避免整簇删除不可归因。|
|3|`submit_v46b_micro_del_372_03_gene_con_trt`|-1|1|0|`数据/A榜/v46b_safe/submit_v46b_micro_del_372_03_gene_con_trt.zip`|单条微消融：样本 372 的 GENE-CON-TRT，避免整簇删除不可归因。|
|4|`submit_v46b_micro_del_372_04_gene_con_trt`|-1|1|0|`数据/A榜/v46b_safe/submit_v46b_micro_del_372_04_gene_con_trt.zip`|单条微消融：样本 372 的 GENE-CON-TRT，避免整簇删除不可归因。|
|5|`submit_v46b_micro_del_50_05_qtl_aff_bis`|-1|1|0|`数据/A榜/v46b_safe/submit_v46b_micro_del_50_05_qtl_aff_bis.zip`|单条微消融：样本 50 的 QTL-AFF-BIS，避免整簇删除不可归因。|
|6|`submit_v46b_micro_del_50_06_qtl_aff_bis`|-1|1|0|`数据/A榜/v46b_safe/submit_v46b_micro_del_50_06_qtl_aff_bis.zip`|单条微消融：样本 50 的 QTL-AFF-BIS，避免整簇删除不可归因。|
|7|`submit_v46b_micro_del_50_07_qtl_aff_bis`|-1|1|0|`数据/A榜/v46b_safe/submit_v46b_micro_del_50_07_qtl_aff_bis.zip`|单条微消融：样本 50 的 QTL-AFF-BIS，避免整簇删除不可归因。|
|8|`submit_v46b_micro_del_80_08_var_oci_gst`|-1|1|0|`数据/A榜/v46b_safe/submit_v46b_micro_del_80_08_var_oci_gst.zip`|单条微消融：样本 80 的 VAR-OCI-GST，避免整簇删除不可归因。|
|9|`submit_v46b_micro_del_399_09_var_oci_gst`|-1|1|0|`数据/A榜/v46b_safe/submit_v46b_micro_del_399_09_var_oci_gst.zip`|单条微消融：样本 399 的 VAR-OCI-GST，避免整簇删除不可归因。|
|10|`submit_v46b_micro_add_consensus_01_49_var_con_cross`|1|1|0|`数据/A榜/v46b_safe/submit_v46b_micro_add_consensus_01_49_var_con_cross.zip`|v46b 保守加法：该关系缺失于 v44 底座，但出现在 6 个历史保守版本，训练类型频次 8，来源=submit_v40_abs_trt_precise.json;submit_v40_var_has_precise.json;submit_v41_precise_strict.json;submit_v41_precise_ultrasafe.json;submit_v42_precise_add.json;submit_v42_subtract_plus_add.json。|
|11|`submit_v46b_micro_add_consensus_02_49_var_con_cross`|1|1|0|`数据/A榜/v46b_safe/submit_v46b_micro_add_consensus_02_49_var_con_cross.zip`|v46b 保守加法：该关系缺失于 v44 底座，但出现在 6 个历史保守版本，训练类型频次 8，来源=submit_v40_abs_trt_precise.json;submit_v40_var_has_precise.json;submit_v41_precise_strict.json;submit_v41_precise_ultrasafe.json;submit_v42_precise_add.json;submit_v42_subtract_plus_add.json。|
|12|`submit_v46b_micro_add_consensus_03_131_var_con_cross`|1|1|0|`数据/A榜/v46b_safe/submit_v46b_micro_add_consensus_03_131_var_con_cross.zip`|v46b 保守加法：该关系缺失于 v44 底座，但出现在 6 个历史保守版本，训练类型频次 8，来源=submit_v40_abs_trt_precise.json;submit_v40_var_has_precise.json;submit_v41_precise_strict.json;submit_v41_precise_ultrasafe.json;submit_v42_precise_add.json;submit_v42_subtract_plus_add.json。|

## 3. 差异明细

|候选|样本idx|动作|修改前类型|修改后类型|修改前关系|修改后关系|
|---|---:|---|---|---|---|---|
|`submit_v46b_micro_del_372_01_gene_con_trt`|372|delete|GENE-CON-TRT||AsTCP genes(GENE) --CON--> hormone response(TRT)||
|`submit_v46b_micro_del_372_02_gene_con_trt`|372|delete|GENE-CON-TRT||AsTCP genes(GENE) --CON--> abiotic stress(TRT)||
|`submit_v46b_micro_del_372_03_gene_con_trt`|372|delete|GENE-CON-TRT||AsTCP genes(GENE) --CON--> light response(TRT)||
|`submit_v46b_micro_del_372_04_gene_con_trt`|372|delete|GENE-CON-TRT||AsTCP genes(GENE) --CON--> growth and development(TRT)||
|`submit_v46b_micro_del_50_05_qtl_aff_bis`|50|delete|QTL-AFF-BIS||Resistance loci(QTL) --AFF--> pathotypes from Texas and Puerto Rico(BIS)||
|`submit_v46b_micro_del_50_06_qtl_aff_bis`|50|delete|QTL-AFF-BIS||resistance locus(QTL) --AFF--> pathotypes from Arkansas(BIS)||
|`submit_v46b_micro_del_50_07_qtl_aff_bis`|50|delete|QTL-AFF-BIS||resistance locus(QTL) --AFF--> pathotypes from Georgia(BIS)||
|`submit_v46b_micro_del_80_08_var_oci_gst`|80|delete|VAR-OCI-GST||Baiyan 2(VAR) --OCI--> three-leaf stage(GST)||
|`submit_v46b_micro_del_399_09_var_oci_gst`|399|delete|VAR-OCI-GST||BTx623(VAR) --OCI--> seed development(GST)||
|`submit_v46b_micro_add_consensus_01_49_var_con_cross`|49|add||VAR-CON-CROSS||Aininghuang(VAR) --CON--> F-2 population(CROSS)|
|`submit_v46b_micro_add_consensus_02_49_var_con_cross`|49|add||VAR-CON-CROSS||Jingu 21(VAR) --CON--> F-2 population(CROSS)|
|`submit_v46b_micro_add_consensus_03_131_var_con_cross`|131|add||VAR-CON-CROSS||BTx623(VAR) --CON--> 96 F2:7 recombinant inbred lines (RILs)(CROSS)|

## 4. 提交纪律

v46b 的目标不是一次豪赌，而是在首个大跌后恢复可归因性。建议每天最多提交 2—3 个，优先选单条微消融；若连续两个微消融均低于 0.4514，应停止减法，转向历史共识微加法。

