# v46 第一个候选失败诊断

用户反馈 `submit_v46_direction_gene_loi_mrk_delete.zip` 平台分数为 **0.4167**，相对 0.4514 底座下降 **0.0347**。这不是随机波动，而是强烈反证：被删除的 5 条 `GENE-LOI-MRK` 在榜上很可能高度正确，或者该类型承担了关键关系召回。

## 1. 被删除关系清单

|样本idx|关系|文本证据摘录|
|---:|---|---|
|13|lgs gene(GENE) --LOI--> microsatellite markers SB3344(MRK)|Using a linkage map with 367 markers (DArT and SSRs) and an in vitro assay for germination stimulant activity towards Striga asiatica in 354 recombinant inbred lines from SRN39 (low stimulant) x Shanqui Red (high stimulant), the lgs gene was mapped on SBI-05 b|
|13|lgs gene(GENE) --LOI--> SB3352(MRK)|Using a linkage map with 367 markers (DArT and SSRs) and an in vitro assay for germination stimulant activity towards Striga asiatica in 354 recombinant inbred lines from SRN39 (low stimulant) x Shanqui Red (high stimulant), the lgs gene was mapped on SBI-05 b|
|103|HORVU7Hr1G000320(GENE) --LOI--> SNP7(MRK)|Two candidate genes, HORVU7Hr1G000320 and HORVU7Hr1G000040, are linked to SNP7. They belong to the nucleotide triphosphate hydrolase superfamily and may affect beta-glucan synthase activity. Another candidate gene, HORVU1Hr1G000010, is associated with SNP1 and|
|103|HORVU7Hr1G000040(GENE) --LOI--> SNP7(MRK)|Two candidate genes, HORVU7Hr1G000320 and HORVU7Hr1G000040, are linked to SNP7. They belong to the nucleotide triphosphate hydrolase superfamily and may affect beta-glucan synthase activity. Another candidate gene, HORVU1Hr1G000010, is associated with SNP1 and|
|103|HORVU1Hr1G000010(GENE) --LOI--> SNP1(MRK)|Two candidate genes, HORVU7Hr1G000320 and HORVU7Hr1G000040, are linked to SNP7. They belong to the nucleotide triphosphate hydrolase superfamily and may affect beta-glucan synthase activity. Another candidate gene, HORVU1Hr1G000010, is associated with SNP1 and|

## 2. 类型频次与诊断

|关系类型|训练集频次|v44底座频次|删除版频次|换向版频次|解释|
|---|---:|---:|---:|---:|---|
|GENE-LOI-MRK|2|5|0|0|虽然训练频次低，但 A榜证据表明此类型不能整体删除；它可能是测试分布特有高价值召回。|
|MRK-LOI-GENE|22|2|2|7|换向只改变角色不减少召回，风险低于删除，但若官方标注以基因作 head，则换向仍会掉分。|
|GENE-CON-TRT|1|4|4|4|仍可单独验证，但必须降低修改规模，避免再出现整簇大删。|
|QTL-AFF-BIS|1|3|3|3|仍可单独验证，但必须降低修改规模，避免再出现整簇大删。|
|VAR-OCI-GST|1|2|2|2|仍可单独验证，但必须降低修改规模，避免再出现整簇大删。|

## 3. 策略修正

第一，删除型方向纠错被证伪，应立即禁用 `submit_v46_combo_gene_loi_mrk_del_cluster372.zip`，并停止任何包含删除这 5 条 `GENE-LOI-MRK` 的组合。第二，下一步若仍要验证方向，优先使用已生成的换向版，因为它保留关系数量，但需意识到换向可能同样破坏官方 head/tail。第三，低频样本簇删除仍可能有效，但本次大跌提示“训练低频不等于测试假阳性”，因此应把样本簇候选拆到更小粒度，优先一条或两条关系的微消融，而不是一次删除 3—4 条。

## 4. 下一步建议

|优先级|动作|理由|
|---:|---|---|
|1|暂不提交组合候选，冻结 `GENE-LOI-MRK` 删除路线|第一个候选已经 -0.0347，组合只会扩大风险|
|2|可提交 `submit_v46_direction_gene_loi_mrk_swap.zip`，但应视为高风险对照|它保留召回，能判断官方是否偏好反向；若再大跌，则方向纠错彻底停止|
|3|生成 v46b 微消融：将样本 372、50、80、399 的删除拆为单样本/单关系候选|避免一次删除多条关系造成不可归因损失|
|4|生成保守加法候选：从历史高分相邻版本找“曾经存在但 v44 删除”的 1—3 条候选，而非继续减法|第一个结果表明当前底座可能召回不足，不能只做减法|
