# v46 原子候选提交账本

作者：**Manus AI**  
日期：2026-04-30  
底座文件：`数据/A榜/submit_v44_del_var_con_cross.json`  
底座分数：**0.4514**  
执行状态：已生成候选、已校验、已打包；等待逐个提交回填分数。

## 一、执行原则

本轮已经从计划阶段进入执行阶段。所有 v46 候选均以当前最优底座 `submit_v44_del_var_con_cross.json` 为唯一基础，不混入其它版本的新增关系。核心纪律是 **一假设一提交、一提交一回填、一涨跌一决策**。如果某个候选掉分，不能继续把它与其它候选组合；如果某个候选涨分，也必须先记录分数，再决定是否进入组合候选。

> **提交红线**：不要一次性上传多个候选后再比较截图；必须按下表顺序逐个提交，并在本账本中记录平台返回分数。

## 二、第一批候选提交顺序

| 顺序 | 候选 zip | 修改规模 | 假设 | 当前状态 | A榜分数 | 结论 |
|---:|---|---:|---|---|---:|---|
| 1 | `数据/A榜/v46_atomic/submit_v46_direction_gene_loi_mrk_delete.zip` | -5 关系 | 删除 5 条 `GENE-LOI-MRK`，验证方向异常是否为假阳性 | 已提交 | 0.4167 | 强烈证伪：不得继续使用该删除假设 |
| 2 | `数据/A榜/v46_atomic/submit_v46_direction_gene_loi_mrk_swap.zip` | 0 关系净变化 | 将同 5 条关系换向为 `MRK-LOI-GENE`，与删除版做对照 | 已生成、已校验 | 待填 | 待定 |
| 3 | `数据/A榜/v46_atomic/submit_v46_lowfreq_gene_con_trt_cluster372.zip` | -4 关系 | 删除样本 372 的 `GENE-CON-TRT` 低频集中簇 | 已生成、已校验 | 待填 | 待定 |
| 4 | `数据/A榜/v46_atomic/submit_v46_lowfreq_qtl_aff_bis_cluster50.zip` | -3 关系 | 删除样本 50 的 `QTL-AFF-BIS` 低频集中簇 | 已生成、已校验 | 待填 | 待定 |
| 5 | `数据/A榜/v46_atomic/submit_v46_lowfreq_var_oci_gst_pair.zip` | -2 关系 | 删除 2 条 `VAR-OCI-GST` 观察候选 | 已生成、已校验 | 待填 | 低优先级 |
| 6 | `数据/A榜/v46_atomic/submit_v46_combo_gene_loi_mrk_del_cluster372.zip` | -9 关系 | 仅当第 1 与第 3 均涨分时，验证组合叠加收益 | 已禁用 | 不提交 | 第 1 已大幅掉分，组合路径作废 |

## 三、候选校验摘要

所有候选文件均已通过仓库既有 `提示词库/validate_submission.py` 校验。校验结果显示每个候选均包含 400 条样本，错误数为 0，zip 内部文件名均为 `submit.json`，可直接用于天池上传。

| 候选 | 样本数 | 校验错误 | 校验警告 | zip 内部结构 |
|---|---:|---:|---:|---|
| `submit_v46_direction_gene_loi_mrk_delete` | 400 | 0 | 1 | `submit.json` |
| `submit_v46_direction_gene_loi_mrk_swap` | 400 | 0 | 1 | `submit.json` |
| `submit_v46_lowfreq_gene_con_trt_cluster372` | 400 | 0 | 1 | `submit.json` |
| `submit_v46_lowfreq_qtl_aff_bis_cluster50` | 400 | 0 | 1 | `submit.json` |
| `submit_v46_lowfreq_var_oci_gst_pair` | 400 | 0 | 1 | `submit.json` |
| `submit_v46_combo_gene_loi_mrk_del_cluster372` | 400 | 0 | 1 | `submit.json` |

警告来自无实体样本，属于原仓库校验脚本明确标注可忽略的正常现象，不影响提交。

## 四、决策树

提交第 1 个候选后，如果分数高于 0.4514，应把 `GENE-LOI-MRK` 删除作为新的临时底座方向，并继续提交第 3 个样本簇消融；如果分数低于 0.4514，则不要提交组合候选，应提交第 2 个换向候选进行对照。如果第 2 个换向候选涨分高于删除版，后续方向矩阵应优先走“换向”而不是“删除”。

提交第 3 个候选后，如果分数高于 0.4514，说明低频样本簇清理有效，可以继续第 4 个候选；如果第 3 个掉分，应停止所有 `GENE-CON-TRT` 类整簇删除，改为 LLM-QA 单条复核。提交第 4 个候选后，如果涨分，低频病害/pathotype 误配路线可扩展；如果掉分，`QTL-AFF-BIS` 需要回到人工语义判别。

| 观测结果 | 下一步 |
|---|---|
| 第 1 个删除版涨分，第 2 个换向版不如删除版 | 固化“方向异常删除”路线，后续从方向矩阵找同类低频反向族 |
| 第 2 个换向版涨分高于删除版 | 固化“换向纠错”路线，优先做 `head/tail` 角色互换候选 |
| 第 1 与第 3 均涨分 | 可以提交第 6 个组合候选验证是否可叠加 |
| 第 1、第 2 均掉分 | 暂停方向纠错，优先执行样本簇消融和 QA 证据表 |
| 第 3、第 4 均掉分 | 暂停低频删除，进入 LLM-QA 与外部弱监督候选排序 |

## 五、回填模板

每次提交后请复制一行并填写平台返回结果。若你希望我继续自动维护账本，把分数发给我即可。

| 提交时间 | 候选 | 平台分数 | 相对 0.4514 | 结论 | 下一步 |
|---|---|---:|---:|---|---|
| 2026-04-30 | `submit_v46_direction_gene_loi_mrk_delete.zip` | 0.4167 | -0.0347 | 删除 5 条 `GENE-LOI-MRK` 造成大幅掉分，说明这些关系在榜上高度必要或删除破坏关键召回 | 停止所有包含该删除动作的组合候选；优先诊断是否存在方向换向、样本簇消融或保守加法路径 |
| 待填 | `submit_v46_direction_gene_loi_mrk_swap.zip` | 待填 | 待填 | 待填 | 待填 |
| 待填 | `submit_v46_lowfreq_gene_con_trt_cluster372.zip` | 待填 | 待填 | 待填 | 待填 |
| 待填 | `submit_v46_lowfreq_qtl_aff_bis_cluster50.zip` | 待填 | 待填 | 待填 | 待填 |
| 待填 | `submit_v46_lowfreq_var_oci_gst_pair.zip` | 待填 | 待填 | 待填 | 待填 |
| 待填 | `submit_v46_combo_gene_loi_mrk_del_cluster372.zip` | 待填 | 待填 | 待填 | 待填 |

## 六、已生成辅助文件

| 文件 | 用途 |
|---|---|
| `分析报告/v46_atomic_execution_report_20260430.md` | 第一批候选生成报告，包含底座统计、候选清单与差异明细 |
| `分析报告/v46_atomic_diff_20260430.csv` | 所有候选的逐条关系级差异表 |
| `脚本工具/make_v46_atomic_candidates.py` | 可复现生成脚本 |
| `数据/A榜/v46_atomic/*.json` | 每个候选的原始 JSON 文件 |
| `数据/A榜/v46_atomic/*.zip` | 可直接上传的天池提交包 |
