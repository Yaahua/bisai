# v46 第一批原子候选执行报告

本报告由 `脚本工具/make_v46_atomic_candidates.py` 自动生成。所有候选均以 `submit_v44_del_var_con_cross.json` 为底座，目标是执行已拍板的“离线大召回、线上小提交”策略。

## 1. 底座统计

|项目|数值|
|---|---:|
|样本数|400|
|实体数|2874|
|关系数|1052|
|无关系样本数|112|
|关系类型数|60|

## 2. 候选文件清单

|建议提交顺序|候选|关系变化|修改条数|校验错误|提交 zip|假设|
|---:|---|---:|---:|---:|---|---|
|1|`submit_v46_direction_gene_loi_mrk_delete`|-5|5|0|`数据/A榜/v46_atomic/submit_v46_direction_gene_loi_mrk_delete.zip`|第一优先级：删除 5 条 GENE-LOI-MRK，验证方向异常是否为 FP。|
|2|`submit_v46_direction_gene_loi_mrk_swap`|0|5|0|`数据/A榜/v46_atomic/submit_v46_direction_gene_loi_mrk_swap.zip`|第一优先级对照：将 5 条 GENE-LOI-MRK 换向为 MRK-LOI-GENE。|
|3|`submit_v46_lowfreq_gene_con_trt_cluster372`|-4|4|0|`数据/A榜/v46_atomic/submit_v46_lowfreq_gene_con_trt_cluster372.zip`|第二优先级：删除样本 372 的 4 条低频 GENE-CON-TRT。|
|4|`submit_v46_lowfreq_qtl_aff_bis_cluster50`|-3|3|0|`数据/A榜/v46_atomic/submit_v46_lowfreq_qtl_aff_bis_cluster50.zip`|第三优先级：删除样本 50 的 3 条低频 QTL-AFF-BIS。|
|5|`submit_v46_lowfreq_var_oci_gst_pair`|-2|2|0|`数据/A榜/v46_atomic/submit_v46_lowfreq_var_oci_gst_pair.zip`|观察候选：删除 2 条 VAR-OCI-GST。|
|6|`submit_v46_combo_gene_loi_mrk_del_cluster372`|-9|9|0|`数据/A榜/v46_atomic/submit_v46_combo_gene_loi_mrk_del_cluster372.zip`|仅在前两个单点均涨分后考虑：方向删除 + 样本 372 删除组合。|

## 3. 差异明细

完整差异已保存到 `分析报告/v46_atomic_diff_20260430.csv`。下表列出全部原子修改，便于提交前复核。

|候选|样本idx|动作|修改前类型|修改后类型|修改前关系|修改后关系|
|---|---:|---|---|---|---|---|
|`submit_v46_direction_gene_loi_mrk_delete`|13|delete|GENE-LOI-MRK||lgs gene->LOI->microsatellite markers SB3344||
|`submit_v46_direction_gene_loi_mrk_delete`|13|delete|GENE-LOI-MRK||lgs gene->LOI->SB3352||
|`submit_v46_direction_gene_loi_mrk_delete`|103|delete|GENE-LOI-MRK||HORVU7Hr1G000320->LOI->SNP7||
|`submit_v46_direction_gene_loi_mrk_delete`|103|delete|GENE-LOI-MRK||HORVU7Hr1G000040->LOI->SNP7||
|`submit_v46_direction_gene_loi_mrk_delete`|103|delete|GENE-LOI-MRK||HORVU1Hr1G000010->LOI->SNP1||
|`submit_v46_direction_gene_loi_mrk_swap`|13|swap|GENE-LOI-MRK|MRK-LOI-GENE|lgs gene->LOI->microsatellite markers SB3344|microsatellite markers SB3344->LOI->lgs gene|
|`submit_v46_direction_gene_loi_mrk_swap`|13|swap|GENE-LOI-MRK|MRK-LOI-GENE|lgs gene->LOI->SB3352|SB3352->LOI->lgs gene|
|`submit_v46_direction_gene_loi_mrk_swap`|103|swap|GENE-LOI-MRK|MRK-LOI-GENE|HORVU7Hr1G000320->LOI->SNP7|SNP7->LOI->HORVU7Hr1G000320|
|`submit_v46_direction_gene_loi_mrk_swap`|103|swap|GENE-LOI-MRK|MRK-LOI-GENE|HORVU7Hr1G000040->LOI->SNP7|SNP7->LOI->HORVU7Hr1G000040|
|`submit_v46_direction_gene_loi_mrk_swap`|103|swap|GENE-LOI-MRK|MRK-LOI-GENE|HORVU1Hr1G000010->LOI->SNP1|SNP1->LOI->HORVU1Hr1G000010|
|`submit_v46_lowfreq_gene_con_trt_cluster372`|372|delete|GENE-CON-TRT||AsTCP genes->CON->hormone response||
|`submit_v46_lowfreq_gene_con_trt_cluster372`|372|delete|GENE-CON-TRT||AsTCP genes->CON->abiotic stress||
|`submit_v46_lowfreq_gene_con_trt_cluster372`|372|delete|GENE-CON-TRT||AsTCP genes->CON->light response||
|`submit_v46_lowfreq_gene_con_trt_cluster372`|372|delete|GENE-CON-TRT||AsTCP genes->CON->growth and development||
|`submit_v46_lowfreq_qtl_aff_bis_cluster50`|50|delete|QTL-AFF-BIS||Resistance loci->AFF->pathotypes from Texas and Puerto Rico||
|`submit_v46_lowfreq_qtl_aff_bis_cluster50`|50|delete|QTL-AFF-BIS||resistance locus->AFF->pathotypes from Arkansas||
|`submit_v46_lowfreq_qtl_aff_bis_cluster50`|50|delete|QTL-AFF-BIS||resistance locus->AFF->pathotypes from Georgia||
|`submit_v46_lowfreq_var_oci_gst_pair`|80|delete|VAR-OCI-GST||Baiyan 2->OCI->three-leaf stage||
|`submit_v46_lowfreq_var_oci_gst_pair`|399|delete|VAR-OCI-GST||BTx623->OCI->seed development||
|`submit_v46_combo_gene_loi_mrk_del_cluster372`|13|delete|GENE-LOI-MRK||lgs gene->LOI->microsatellite markers SB3344||
|`submit_v46_combo_gene_loi_mrk_del_cluster372`|13|delete|GENE-LOI-MRK||lgs gene->LOI->SB3352||
|`submit_v46_combo_gene_loi_mrk_del_cluster372`|103|delete|GENE-LOI-MRK||HORVU7Hr1G000320->LOI->SNP7||
|`submit_v46_combo_gene_loi_mrk_del_cluster372`|103|delete|GENE-LOI-MRK||HORVU7Hr1G000040->LOI->SNP7||
|`submit_v46_combo_gene_loi_mrk_del_cluster372`|103|delete|GENE-LOI-MRK||HORVU1Hr1G000010->LOI->SNP1||
|`submit_v46_combo_gene_loi_mrk_del_cluster372`|372|delete|GENE-CON-TRT||AsTCP genes->CON->hormone response||
|`submit_v46_combo_gene_loi_mrk_del_cluster372`|372|delete|GENE-CON-TRT||AsTCP genes->CON->abiotic stress||
|`submit_v46_combo_gene_loi_mrk_del_cluster372`|372|delete|GENE-CON-TRT||AsTCP genes->CON->light response||
|`submit_v46_combo_gene_loi_mrk_del_cluster372`|372|delete|GENE-CON-TRT||AsTCP genes->CON->growth and development||

## 4. 执行纪律

第一轮只建议提交前四个单假设候选。组合候选 `submit_v46_combo_gene_loi_mrk_del_cluster372` 只应在 `GENE-LOI-MRK` 删除版和样本 372 删除版均确认涨分后提交。`VAR-OCI-GST` 双条删除属于观察候选，优先级低于方向纠错和两个样本簇消融。

每次提交后必须把分数写入提交账本，并根据实际涨跌决定下一步，不应一次性上传多个候选导致因果不可归因。

