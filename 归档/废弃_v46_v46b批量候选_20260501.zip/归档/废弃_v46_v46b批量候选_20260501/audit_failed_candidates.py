import json
import zipfile
import hashlib
from pathlib import Path
from collections import Counter

ROOT = Path('/home/ubuntu/bisai')
files = {
    'baseline_v44_json': ROOT/'数据/A榜/submit_v44_del_var_con_cross.json',
    'fail_04167_json': ROOT/'数据/A榜/v46_atomic/submit_v46_direction_gene_loi_mrk_delete.json',
    'fail_04164_json': ROOT/'数据/A榜/v46b_safe/submit_v46b_micro_del_372_01_gene_con_trt.json',
    'fail_04162_json': ROOT/'数据/A榜/v46b_safe/submit_v46b_micro_add_consensus_01_49_var_con_cross.json',
}
zips = {
    'fail_04167_zip': ROOT/'数据/A榜/v46_atomic/submit_v46_direction_gene_loi_mrk_delete.zip',
    'fail_04164_zip': ROOT/'数据/A榜/v46b_safe/submit_v46b_micro_del_372_01_gene_con_trt.zip',
    'fail_04162_zip': ROOT/'数据/A榜/v46b_safe/submit_v46b_micro_add_consensus_01_49_var_con_cross.zip',
}

def md5(p):
    return hashlib.md5(p.read_bytes()).hexdigest() if p.exists() else 'MISSING'

def load(p):
    return json.loads(p.read_text(encoding='utf-8'))

def rels(sample):
    # robustly detect all relation-like fields
    out = []
    for k in ['relations','relation_of_mention','relation_list','spo_list']:
        v = sample.get(k)
        if isinstance(v, list):
            out.extend((k, r) for r in v)
    return out

def canon_rel(r):
    return tuple((k, str(r.get(k,''))) for k in sorted(r.keys()))

def sample_sig(s):
    # ignore accidental added alternate relation fields? no, full keys below separately
    return json.dumps(s, ensure_ascii=False, sort_keys=True)

lines=[]
lines.append('# v46/v46b 三连 0.416x 根因审计\n')
lines.append('## 1. 文件身份\n')
lines.append('|名称|路径|存在|大小|MD5|')
lines.append('|---|---|---:|---:|---|')
for name,p in {**files, **zips}.items():
    lines.append(f'|{name}|`{p.relative_to(ROOT)}`|{p.exists()}|{p.stat().st_size if p.exists() else 0}|`{md5(p)}`|')

lines.append('\n## 2. JSON 顶层与样本字段审计\n')
lines.append('|名称|样本数|样本0字段|关系字段计数|总关系数|关系标签Top10|')
lines.append('|---|---:|---|---|---:|---|')
loaded={}
for name,p in files.items():
    d=load(p); loaded[name]=d
    key_counter=Counter()
    label_counter=Counter()
    total=0
    for s in d:
        for k,r in rels(s):
            key_counter[k]+=1
            total+=1
            label_counter[r.get('label') or r.get('relation') or r.get('predicate') or 'NO_LABEL']+=1
    sample_keys=', '.join(sorted(d[0].keys()))
    lines.append(f'|{name}|{len(d)}|`{sample_keys}`|`{dict(key_counter)}`|{total}|`{label_counter.most_common(10)}`|')

lines.append('\n## 3. zip 内部 submit.json 审计\n')
lines.append('|zip|内部文件|submit.json MD5|与同名 JSON 是否一致|submit样本数|submit总关系数|')
lines.append('|---|---|---|---:|---:|---:|')
zip_to_json = {
    'fail_04167_zip':'fail_04167_json',
    'fail_04164_zip':'fail_04164_json',
    'fail_04162_zip':'fail_04162_json',
}
for zname,zp in zips.items():
    if not zp.exists():
        lines.append(f'|{zname}|MISSING|MISSING|False|0|0|')
        continue
    with zipfile.ZipFile(zp) as zf:
        names=zf.namelist()
        data=zf.read('submit.json') if 'submit.json' in names else zf.read(names[0])
    zmd5=hashlib.md5(data).hexdigest()
    same = zmd5 == md5(files[zip_to_json[zname]])
    obj=json.loads(data.decode('utf-8'))
    total=sum(len(rels(s)) for s in obj)
    lines.append(f'|{zname}|`{names}`|`{zmd5}`|{same}|{len(obj)}|{total}|')

lines.append('\n## 4. 候选相对底座的全量样本差异数量\n')
base=loaded['baseline_v44_json']
lines.append('|候选|不同样本数|不同样本idx前20|关系总数变化|说明|')
lines.append('|---|---:|---|---:|---|')
base_total=sum(len(rels(s)) for s in base)
for name in ['fail_04167_json','fail_04164_json','fail_04162_json']:
    d=loaded[name]
    diff_idxs=[i for i,(a,b) in enumerate(zip(base,d)) if sample_sig(a)!=sample_sig(b)]
    total=sum(len(rels(s)) for s in d)
    lines.append(f'|{name}|{len(diff_idxs)}|`{diff_idxs[:20]}`|{total-base_total}|如果不是预期的 1 或 5 附近，则生成脚本污染了结构|')

lines.append('\n## 5. 差异样本的字段级变更摘要\n')
for name in ['fail_04167_json','fail_04164_json','fail_04162_json']:
    d=loaded[name]
    diff_idxs=[i for i,(a,b) in enumerate(zip(base,d)) if sample_sig(a)!=sample_sig(b)]
    lines.append(f'\n### {name}\n')
    for i in diff_idxs[:10]:
        a,b=base[i],d[i]
        lines.append(f'- idx {i}: base_keys={sorted(a.keys())}; cand_keys={sorted(b.keys())}')
        for k in sorted(set(a.keys())|set(b.keys())):
            if json.dumps(a.get(k),ensure_ascii=False,sort_keys=True)!=json.dumps(b.get(k),ensure_ascii=False,sort_keys=True):
                av=a.get(k); bv=b.get(k)
                if isinstance(av, list) or isinstance(bv, list):
                    lines.append(f'  - `{k}` length: {len(av) if isinstance(av,list) else "NA"} -> {len(bv) if isinstance(bv,list) else "NA"}')
                else:
                    lines.append(f'  - `{k}` changed')

out=ROOT/'分析报告/root_cause_audit_20260501.md'
out.write_text('\n'.join(lines)+'\n',encoding='utf-8')
print(out)
