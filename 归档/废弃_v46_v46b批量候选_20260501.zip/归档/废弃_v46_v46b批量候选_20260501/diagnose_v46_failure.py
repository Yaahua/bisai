#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""诊断 v46 第一个候选大幅掉分原因。"""

from __future__ import annotations

import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path('/home/ubuntu/bisai')
BASE = ROOT / '数据/A榜/submit_v44_del_var_con_cross.json'
DEL = ROOT / '数据/A榜/v46_atomic/submit_v46_direction_gene_loi_mrk_delete.json'
SWAP = ROOT / '数据/A榜/v46_atomic/submit_v46_direction_gene_loi_mrk_swap.json'
TRAIN = ROOT / '数据/官方原始数据/train.json'
OUT = ROOT / '分析报告/v46_failure_diagnosis_20260430.md'


def load(p):
    with open(p, encoding='utf-8') as f:
        return json.load(f)


def rtype(r):
    return f"{r.get('head_type')}-{r.get('label')}-{r.get('tail_type')}"


def rkey(r):
    return (r.get('head_start'), r.get('head_end'), r.get('head_type'), r.get('label'), r.get('tail_start'), r.get('tail_end'), r.get('tail_type'))


def brief(r):
    return f"{r.get('head')}({r.get('head_type')}) --{r.get('label')}--> {r.get('tail')}({r.get('tail_type')})"


def main():
    base, dele, swap, train = map(load, [BASE, DEL, SWAP, TRAIN])
    train_type = Counter(rtype(r) for item in train for r in item.get('relations', []))
    base_type = Counter(rtype(r) for item in base for r in item.get('relations', []))
    del_type = Counter(rtype(r) for item in dele for r in item.get('relations', []))
    swap_type = Counter(rtype(r) for item in swap for r in item.get('relations', []))

    deleted = []
    swapped = []
    for i, (b, d, s) in enumerate(zip(base, dele, swap)):
        dkeys = {rkey(r) for r in d.get('relations', [])}
        skeys = {rkey(r) for r in s.get('relations', [])}
        bkeys = {rkey(r): r for r in b.get('relations', [])}
        for k, r in bkeys.items():
            if k not in dkeys:
                deleted.append((i, r, b.get('text','')))
            if k not in skeys and rtype(r) == 'GENE-LOI-MRK':
                # 在 swap 版中找同 span 反向
                swapped.append((i, r, b.get('text','')))

    md = []
    md.append('# v46 第一个候选失败诊断\n')
    md.append('用户反馈 `submit_v46_direction_gene_loi_mrk_delete.zip` 平台分数为 **0.4167**，相对 0.4514 底座下降 **0.0347**。这不是随机波动，而是强烈反证：被删除的 5 条 `GENE-LOI-MRK` 在榜上很可能高度正确，或者该类型承担了关键关系召回。\n')
    md.append('## 1. 被删除关系清单\n')
    md.append('|样本idx|关系|文本证据摘录|')
    md.append('|---:|---|---|')
    for i, r, text in deleted:
        md.append(f"|{i}|{brief(r)}|{text[:260].replace('|','/')}|")
    md.append('\n## 2. 类型频次与诊断\n')
    md.append('|关系类型|训练集频次|v44底座频次|删除版频次|换向版频次|解释|')
    md.append('|---|---:|---:|---:|---:|---|')
    for t in ['GENE-LOI-MRK','MRK-LOI-GENE','GENE-CON-TRT','QTL-AFF-BIS','VAR-OCI-GST']:
        explanation = ''
        if t == 'GENE-LOI-MRK':
            explanation = '虽然训练频次低，但 A榜证据表明此类型不能整体删除；它可能是测试分布特有高价值召回。'
        elif t == 'MRK-LOI-GENE':
            explanation = '换向只改变角色不减少召回，风险低于删除，但若官方标注以基因作 head，则换向仍会掉分。'
        else:
            explanation = '仍可单独验证，但必须降低修改规模，避免再出现整簇大删。'
        md.append(f"|{t}|{train_type[t]}|{base_type[t]}|{del_type[t]}|{swap_type[t]}|{explanation}|")
    md.append('\n## 3. 策略修正\n')
    md.append('第一，删除型方向纠错被证伪，应立即禁用 `submit_v46_combo_gene_loi_mrk_del_cluster372.zip`，并停止任何包含删除这 5 条 `GENE-LOI-MRK` 的组合。第二，下一步若仍要验证方向，优先使用已生成的换向版，因为它保留关系数量，但需意识到换向可能同样破坏官方 head/tail。第三，低频样本簇删除仍可能有效，但本次大跌提示“训练低频不等于测试假阳性”，因此应把样本簇候选拆到更小粒度，优先一条或两条关系的微消融，而不是一次删除 3—4 条。\n')
    md.append('## 4. 下一步建议\n')
    md.append('|优先级|动作|理由|')
    md.append('|---:|---|---|')
    md.append('|1|暂不提交组合候选，冻结 `GENE-LOI-MRK` 删除路线|第一个候选已经 -0.0347，组合只会扩大风险|')
    md.append('|2|可提交 `submit_v46_direction_gene_loi_mrk_swap.zip`，但应视为高风险对照|它保留召回，能判断官方是否偏好反向；若再大跌，则方向纠错彻底停止|')
    md.append('|3|生成 v46b 微消融：将样本 372、50、80、399 的删除拆为单样本/单关系候选|避免一次删除多条关系造成不可归因损失|')
    md.append('|4|生成保守加法候选：从历史高分相邻版本找“曾经存在但 v44 删除”的 1—3 条候选，而非继续减法|第一个结果表明当前底座可能召回不足，不能只做减法|')
    OUT.write_text('\n'.join(md) + '\n', encoding='utf-8')
    print(OUT)
    print('deleted_count', len(deleted))
    print('base GENE-LOI-MRK', base_type['GENE-LOI-MRK'], 'delete', del_type['GENE-LOI-MRK'], 'swap MRK-LOI-GENE', swap_type['MRK-LOI-GENE'])


if __name__ == '__main__':
    main()
