#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成 v46b 安全候选：禁用 GENE-LOI-MRK 删除，改为微消融与历史共识保守加法。"""

from __future__ import annotations

import copy
import csv
import json
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, List, Tuple

ROOT = Path('/home/ubuntu/bisai')
BASE = ROOT / '数据/A榜/submit_v44_del_var_con_cross.json'
TRAIN = ROOT / '数据/官方原始数据/train.json'
OUT_DIR = ROOT / '数据/A榜/v46b_safe'
REPORT_DIR = ROOT / '分析报告'
DIFF_CSV = REPORT_DIR / 'v46b_safe_diff_20260430.csv'
REPORT_MD = REPORT_DIR / 'v46b_safe_execution_report_20260430.md'
LEDGER_MD = REPORT_DIR / 'v46b_submission_ledger_20260430.md'

Relation = Dict[str, Any]
Item = Dict[str, Any]


def load_json(path: Path) -> List[Item]:
    with path.open(encoding='utf-8') as f:
        return json.load(f)


def rel_type(r: Relation) -> str:
    return f"{r.get('head_type')}-{r.get('label')}-{r.get('tail_type')}"


def rel_key(r: Relation) -> Tuple[Any, ...]:
    return (
        r.get('head'), r.get('head_start'), r.get('head_end'), r.get('head_type'),
        r.get('label'),
        r.get('tail'), r.get('tail_start'), r.get('tail_end'), r.get('tail_type'),
    )


def rel_brief(r: Relation) -> str:
    return f"{r.get('head')}({r.get('head_type')}) --{r.get('label')}--> {r.get('tail')}({r.get('tail_type')})"


def package_zip(json_path: Path) -> Path:
    zip_path = json_path.with_suffix('.zip')
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(json_path, 'submit.json')
    return zip_path


def validate(data: List[Item]) -> List[str]:
    errors = []
    labels = {'CROP','VAR','GENE','QTL','MRK','TRT','ABS','BIS','BM','CHR','CROSS','GST'}
    rels = {'AFF','LOI','HAS','CON','USE','OCI'}
    for i, item in enumerate(data):
        text = item.get('text', '')
        for r in item.get('relations', []):
            for k in ['head','head_start','head_end','head_type','tail','tail_start','tail_end','tail_type','label']:
                if k not in r:
                    errors.append(f'[{i}] relation missing {k}: {r}')
                    break
            else:
                if text[r['head_start']:r['head_end']] != r['head']:
                    errors.append(f'[{i}] head span mismatch: {r}')
                if text[r['tail_start']:r['tail_end']] != r['tail']:
                    errors.append(f'[{i}] tail span mismatch: {r}')
                if r['head_type'] not in labels or r['tail_type'] not in labels or r['label'] not in rels:
                    errors.append(f'[{i}] illegal type: {r}')
    return errors


def summarize(data: List[Item]) -> Dict[str, Any]:
    tc = Counter(rel_type(r) for item in data for r in item.get('relations', []))
    return {
        'items': len(data),
        'entities': sum(len(x.get('entities', [])) for x in data),
        'relations': sum(len(x.get('relations', [])) for x in data),
        'empty_rel_items': sum(1 for x in data if not x.get('relations')),
        'type_counts': tc,
    }


def clone_with_delete_one(base: List[Item], idx: int, target_key: Tuple[Any, ...]) -> Tuple[List[Item], Dict[str, Any]]:
    data = copy.deepcopy(base)
    removed = None
    after = []
    for r in data[idx].get('relations', []):
        if rel_key(r) == target_key and removed is None:
            removed = r
        else:
            after.append(r)
    data[idx]['relations'] = after
    if removed is None:
        raise ValueError('target relation not found')
    return data, {
        'action': 'delete', 'sample_idx': idx,
        'type_before': rel_type(removed), 'type_after': '',
        'relation_before': rel_brief(removed), 'relation_after': '',
        'reason': 'v46b 微消融：第一轮整类删除大跌后，仅删除单条低频可疑关系以控制风险。',
        'text_excerpt': data[idx].get('text', '')[:240].replace('\n', ' '),
    }


def clone_with_add_one(base: List[Item], idx: int, add_rel: Relation, reason: str) -> Tuple[List[Item], Dict[str, Any]]:
    data = copy.deepcopy(base)
    existing = {rel_key(r) for r in data[idx].get('relations', [])}
    if rel_key(add_rel) not in existing:
        data[idx].setdefault('relations', []).append(copy.deepcopy(add_rel))
    return data, {
        'action': 'add', 'sample_idx': idx,
        'type_before': '', 'type_after': rel_type(add_rel),
        'relation_before': '', 'relation_after': rel_brief(add_rel),
        'reason': reason,
        'text_excerpt': data[idx].get('text', '')[:240].replace('\n', ' '),
    }


def build_historical_add_candidates(base: List[Item], train_type: Counter) -> List[Dict[str, Any]]:
    source_names = [
        'submit_v40_abs_trt_precise.json',
        'submit_v40_var_has_precise.json',
        'submit_v41_precise_ultrasafe.json',
        'submit_v41_precise_strict.json',
        'submit_v42_precise_add.json',
        'submit_v42_subtract_plus_add.json',
    ]
    base_keys = [set(rel_key(r) for r in item.get('relations', [])) for item in base]
    bucket: Dict[Tuple[int, Tuple[Any, ...]], Dict[str, Any]] = {}
    for src in source_names:
        p = ROOT / '数据/A榜' / src
        if not p.exists():
            continue
        data = load_json(p)
        for idx, item in enumerate(data):
            if idx >= len(base):
                continue
            for r in item.get('relations', []):
                k = rel_key(r)
                if k in base_keys[idx]:
                    continue
                if rel_type(r) in {'GENE-LOI-MRK', 'MRK-LOI-GENE'}:
                    continue
                obj = bucket.setdefault((idx, k), {'idx': idx, 'relation': r, 'sources': set()})
                obj['sources'].add(src)
    cands = []
    for obj in bucket.values():
        r = obj['relation']
        support = len(obj['sources'])
        t = rel_type(r)
        # 只保留至少两个保守版本共识，或训练频次较高且至少一个超保守来源出现的候选。
        if support >= 2 or (train_type[t] >= 10 and any('ultrasafe' in s or 'strict' in s for s in obj['sources'])):
            cands.append({
                'idx': obj['idx'],
                'relation': r,
                'support': support,
                'sources': sorted(obj['sources']),
                'train_freq': train_type[t],
                'type': t,
            })
    cands.sort(key=lambda x: (-x['support'], -x['train_freq'], x['idx'], x['type']))
    return cands[:5]


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    base = load_json(BASE)
    train = load_json(TRAIN)
    train_type = Counter(rel_type(r) for item in train for r in item.get('relations', []))
    base_summary = summarize(base)

    variants: List[Dict[str, Any]] = []

    # 微消融：拆开第一批中仍未验证的低频样本簇，每个候选只删 1 条。
    micro_targets = []
    for idx, target_type in [(372, 'GENE-CON-TRT'), (50, 'QTL-AFF-BIS'), (80, 'VAR-OCI-GST'), (399, 'VAR-OCI-GST')]:
        for r in base[idx].get('relations', []):
            if rel_type(r) == target_type:
                micro_targets.append((idx, r))
    for seq, (idx, r) in enumerate(micro_targets, 1):
        name = f"submit_v46b_micro_del_{idx}_{seq:02d}_{rel_type(r).lower().replace('-', '_')}"
        data, diff = clone_with_delete_one(base, idx, rel_key(r))
        variants.append({'name': name, 'data': data, 'diffs': [dict(diff, variant=name)], 'hypothesis': f"单条微消融：样本 {idx} 的 {rel_type(r)}，避免整簇删除不可归因。"})

    # 保守加法：来自多个历史保守版本共识，严格排除 GENE/MRK 方向路径。
    add_candidates = build_historical_add_candidates(base, train_type)
    for seq, cand in enumerate(add_candidates[:3], 1):
        name = f"submit_v46b_micro_add_consensus_{seq:02d}_{cand['idx']}_{cand['type'].lower().replace('-', '_')}"
        reason = f"v46b 保守加法：该关系缺失于 v44 底座，但出现在 {cand['support']} 个历史保守版本，训练类型频次 {cand['train_freq']}，来源={';'.join(cand['sources'])}。"
        data, diff = clone_with_add_one(base, cand['idx'], cand['relation'], reason)
        variants.append({'name': name, 'data': data, 'diffs': [dict(diff, variant=name)], 'hypothesis': reason})

    all_diffs: List[Dict[str, Any]] = []
    rows = []
    for v in variants:
        out_json = OUT_DIR / f"{v['name']}.json"
        with out_json.open('w', encoding='utf-8') as f:
            json.dump(v['data'], f, ensure_ascii=False, indent=2)
        out_zip = package_zip(out_json)
        errors = validate(v['data'])
        summary = summarize(v['data'])
        all_diffs.extend(v['diffs'])
        rows.append({
            'name': v['name'], 'zip': out_zip, 'json': out_json,
            'delta': summary['relations'] - base_summary['relations'],
            'diffs': len(v['diffs']), 'errors': len(errors), 'hypothesis': v['hypothesis'],
            'relations': summary['relations'],
        })
        if errors:
            (REPORT_DIR / f"{v['name']}_validation_errors.txt").write_text('\n'.join(errors), encoding='utf-8')

    with DIFF_CSV.open('w', encoding='utf-8', newline='') as f:
        fieldnames = ['variant','sample_idx','action','type_before','type_after','relation_before','relation_after','reason','text_excerpt']
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader(); w.writerows(all_diffs)

    md = []
    md.append('# v46b 安全候选执行报告\n')
    md.append('第一个 v46 候选 `GENE-LOI-MRK` 删除版得分 0.4167，已强烈证伪整类删除假设。因此 v46b 明确排除所有 `GENE-LOI-MRK` 删除组合，改用 **单条微消融** 和 **历史保守共识微加法**。\n')
    md.append('## 1. 底座与约束\n')
    md.append('|项目|数值|')
    md.append('|---|---:|')
    md.append(f"|底座关系数|{base_summary['relations']}|")
    md.append(f"|底座样本数|{base_summary['items']}|")
    md.append('|禁用路径|`GENE-LOI-MRK` 删除及其任何组合|\n')
    md.append('## 2. 候选清单\n')
    md.append('|建议顺序|候选|关系变化|修改条数|校验错误|zip|假设|')
    md.append('|---:|---|---:|---:|---:|---|---|')
    for i, row in enumerate(rows, 1):
        # 先列微消融，再列加法；用户可按账本选择前 3 个。
        md.append(f"|{i}|`{row['name']}`|{row['delta']}|{row['diffs']}|{row['errors']}|`数据/A榜/v46b_safe/{row['zip'].name}`|{row['hypothesis']}|")
    md.append('\n## 3. 差异明细\n')
    md.append('|候选|样本idx|动作|修改前类型|修改后类型|修改前关系|修改后关系|')
    md.append('|---|---:|---|---|---|---|---|')
    for d in all_diffs:
        md.append(f"|`{d['variant']}`|{d['sample_idx']}|{d['action']}|{d['type_before']}|{d['type_after']}|{d['relation_before']}|{d['relation_after']}|")
    md.append('\n## 4. 提交纪律\n')
    md.append('v46b 的目标不是一次豪赌，而是在首个大跌后恢复可归因性。建议每天最多提交 2—3 个，优先选单条微消融；若连续两个微消融均低于 0.4514，应停止减法，转向历史共识微加法。\n')
    REPORT_MD.write_text('\n'.join(md) + '\n', encoding='utf-8')

    ledger = []
    ledger.append('# v46b 提交账本\n')
    ledger.append('底座：`submit_v44_del_var_con_cross.json`，分数 **0.4514**。已知失败：`submit_v46_direction_gene_loi_mrk_delete.zip` 得分 **0.4167**，因此禁用 `GENE-LOI-MRK` 删除组合。\n')
    ledger.append('|顺序|候选|平台分数|相对底座|结论|下一步|')
    ledger.append('|---:|---|---:|---:|---|---|')
    for i, row in enumerate(rows, 1):
        ledger.append(f"|{i}|`{row['zip'].name}`|待填|待填|待填|待填|")
    LEDGER_MD.write_text('\n'.join(ledger) + '\n', encoding='utf-8')

    print('wrote', OUT_DIR)
    print('candidates', len(rows))
    for row in rows:
        print(row['name'], 'delta', row['delta'], 'errors', row['errors'])


if __name__ == '__main__':
    main()
