#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成 v46 第一批原子候选提交。

原则：以 submit_v44_del_var_con_cross.json 为 0.4514 底座；每个候选只验证一个假设；
同时输出 JSON、ZIP、diff 明细和汇总报告，便于提交账本记录。
"""

from __future__ import annotations

import copy
import csv
import json
import os
import zipfile
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Tuple

ROOT = Path('/home/ubuntu/bisai')
BASE = ROOT / '数据' / 'A榜' / 'submit_v44_del_var_con_cross.json'
OUT_DIR = ROOT / '数据' / 'A榜' / 'v46_atomic'
REPORT_DIR = ROOT / '分析报告'
DIFF_CSV = REPORT_DIR / 'v46_atomic_diff_20260430.csv'
REPORT_MD = REPORT_DIR / 'v46_atomic_execution_report_20260430.md'

Relation = Dict[str, Any]
Item = Dict[str, Any]


def load_json(path: Path) -> List[Item]:
    with path.open(encoding='utf-8') as f:
        return json.load(f)


def rel_type(r: Relation) -> str:
    return f"{r.get('head_type')}-{r.get('label')}-{r.get('tail_type')}"


def rel_key(r: Relation) -> Tuple[Any, ...]:
    return (
        r.get('head'), r.get('head_start'), r.get('head_end'), r.get('head_type'),
        r.get('label'),
        r.get('tail'), r.get('tail_start'), r.get('tail_end'), r.get('tail_type'),
    )


def rel_brief(r: Relation) -> str:
    return f"{r.get('head')}->{r.get('label')}->{r.get('tail')}"


def swap_relation(r: Relation) -> Relation:
    """将 head/tail 对调，label 保持不变。"""
    return {
        'head': r['tail'],
        'head_start': r['tail_start'],
        'head_end': r['tail_end'],
        'head_type': r['tail_type'],
        'tail': r['head'],
        'tail_start': r['head_start'],
        'tail_end': r['head_end'],
        'tail_type': r['head_type'],
        'label': r['label'],
    }


def dedupe_relations(rels: List[Relation]) -> List[Relation]:
    seen = set()
    out = []
    for r in rels:
        k = rel_key(r)
        if k not in seen:
            seen.add(k)
            out.append(r)
    return out


def package_zip(json_path: Path) -> Path:
    zip_path = json_path.with_suffix('.zip')
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.write(json_path, 'submit.json')
    return zip_path


def validate_submission(data: List[Item]) -> List[str]:
    errors = []
    valid_labels = {'CROP','VAR','GENE','QTL','MRK','TRT','ABS','BIS','BM','CHR','CROSS','GST'}
    valid_rels = {'AFF','LOI','HAS','CON','USE','OCI'}
    for i, item in enumerate(data):
        text = item.get('text', '')
        if 'entities' not in item:
            errors.append(f'[{i}] 缺少 entities 字段')
        if 'relations' not in item:
            errors.append(f'[{i}] 缺少 relations 字段')
        for e in item.get('entities', []):
            if not isinstance(e.get('start'), int) or not isinstance(e.get('end'), int):
                errors.append(f'[{i}] 实体 start/end 非整数: {e}')
                continue
            if text[e['start']:e['end']] != e.get('text', ''):
                errors.append(f'[{i}] 实体边界不匹配: {e}')
            if e.get('label') not in valid_labels:
                errors.append(f'[{i}] 非法实体类型: {e}')
        for r in item.get('relations', []):
            for k in ['head','head_start','head_end','head_type','tail','tail_start','tail_end','tail_type','label']:
                if k not in r:
                    errors.append(f'[{i}] 关系缺少字段 {k}: {r}')
                    break
            else:
                if text[r['head_start']:r['head_end']] != r['head']:
                    errors.append(f'[{i}] head 边界错误: {r}')
                if text[r['tail_start']:r['tail_end']] != r['tail']:
                    errors.append(f'[{i}] tail 边界错误: {r}')
                if r.get('head_type') not in valid_labels or r.get('tail_type') not in valid_labels:
                    errors.append(f'[{i}] 非法关系实体类型: {r}')
                if r.get('label') not in valid_rels:
                    errors.append(f'[{i}] 非法关系类型: {r}')
    return errors


def summarize(data: List[Item]) -> Dict[str, Any]:
    type_counts = Counter(rel_type(r) for item in data for r in item.get('relations', []))
    return {
        'items': len(data),
        'entities': sum(len(item.get('entities', [])) for item in data),
        'relations': sum(len(item.get('relations', [])) for item in data),
        'empty_rel_items': sum(1 for item in data if not item.get('relations')),
        'types': len(type_counts),
        'type_counts': type_counts,
    }


def make_variant(base: List[Item], name: str, mode: str) -> Tuple[List[Item], List[Dict[str, Any]]]:
    data = copy.deepcopy(base)
    diffs: List[Dict[str, Any]] = []

    def delete_if(idx: int, predicate, reason: str):
        before = data[idx].get('relations', [])
        after = []
        for r in before:
            if predicate(r):
                diffs.append({
                    'variant': name, 'sample_idx': idx, 'action': 'delete',
                    'type_before': rel_type(r), 'type_after': '',
                    'relation_before': rel_brief(r), 'relation_after': '',
                    'reason': reason,
                    'text_excerpt': data[idx].get('text', '')[:220].replace('\n', ' '),
                })
            else:
                after.append(r)
        data[idx]['relations'] = after

    def swap_if(idx: int, predicate, reason: str):
        before = data[idx].get('relations', [])
        after = []
        for r in before:
            if predicate(r):
                sr = swap_relation(r)
                diffs.append({
                    'variant': name, 'sample_idx': idx, 'action': 'swap',
                    'type_before': rel_type(r), 'type_after': rel_type(sr),
                    'relation_before': rel_brief(r), 'relation_after': rel_brief(sr),
                    'reason': reason,
                    'text_excerpt': data[idx].get('text', '')[:220].replace('\n', ' '),
                })
                after.append(sr)
            else:
                after.append(r)
        data[idx]['relations'] = dedupe_relations(after)

    if mode == 'gene_loi_mrk_delete':
        for idx in [13, 103]:
            delete_if(idx, lambda r: rel_type(r) == 'GENE-LOI-MRK', '训练集中 GENE-LOI-MRK 极低频且反向 MRK-LOI-GENE 更强，验证方向异常删除。')
    elif mode == 'gene_loi_mrk_swap':
        for idx in [13, 103]:
            swap_if(idx, lambda r: rel_type(r) == 'GENE-LOI-MRK', '训练集中反向 MRK-LOI-GENE 更强，验证 head/tail 换向。')
    elif mode == 'gene_con_trt_cluster372_delete':
        delete_if(372, lambda r: rel_type(r) == 'GENE-CON-TRT', '样本 372 为低频 GENE-CON-TRT 集中簇，文本更像 promoter cis-elements 含响应元件而非 gene 构成 trait。')
    elif mode == 'qtl_aff_bis_cluster50_delete':
        delete_if(50, lambda r: rel_type(r) == 'QTL-AFF-BIS', '样本 50 为低频 QTL-AFF-BIS 集中簇，疑似 resistance loci against pathotypes 的语义误配。')
    elif mode == 'var_oci_gst_delete':
        for idx in [80, 399]:
            delete_if(idx, lambda r: rel_type(r) == 'VAR-OCI-GST', 'VAR-OCI-GST 训练频次极低，疑似把材料与生长阶段/组织阶段误连为 OCI。')
    elif mode == 'gene_loi_mrk_delete_plus_cluster372':
        for idx in [13, 103]:
            delete_if(idx, lambda r: rel_type(r) == 'GENE-LOI-MRK', '组合验证：方向异常删除。')
        delete_if(372, lambda r: rel_type(r) == 'GENE-CON-TRT', '组合验证：低频样本簇删除。')
    else:
        raise ValueError(f'unknown mode: {mode}')

    return data, diffs


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    REPORT_DIR.mkdir(parents=True, exist_ok=True)
    base = load_json(BASE)
    base_summary = summarize(base)

    variants = [
        ('submit_v46_direction_gene_loi_mrk_delete', 'gene_loi_mrk_delete', '第一优先级：删除 5 条 GENE-LOI-MRK，验证方向异常是否为 FP。'),
        ('submit_v46_direction_gene_loi_mrk_swap', 'gene_loi_mrk_swap', '第一优先级对照：将 5 条 GENE-LOI-MRK 换向为 MRK-LOI-GENE。'),
        ('submit_v46_lowfreq_gene_con_trt_cluster372', 'gene_con_trt_cluster372_delete', '第二优先级：删除样本 372 的 4 条低频 GENE-CON-TRT。'),
        ('submit_v46_lowfreq_qtl_aff_bis_cluster50', 'qtl_aff_bis_cluster50_delete', '第三优先级：删除样本 50 的 3 条低频 QTL-AFF-BIS。'),
        ('submit_v46_lowfreq_var_oci_gst_pair', 'var_oci_gst_delete', '观察候选：删除 2 条 VAR-OCI-GST。'),
        ('submit_v46_combo_gene_loi_mrk_del_cluster372', 'gene_loi_mrk_delete_plus_cluster372', '仅在前两个单点均涨分后考虑：方向删除 + 样本 372 删除组合。'),
    ]

    all_diffs: List[Dict[str, Any]] = []
    report_rows: List[Dict[str, Any]] = []

    for filename, mode, hypothesis in variants:
        data, diffs = make_variant(base, filename, mode)
        errors = validate_submission(data)
        out_json = OUT_DIR / f'{filename}.json'
        with out_json.open('w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        out_zip = package_zip(out_json)
        summary = summarize(data)
        all_diffs.extend(diffs)
        report_rows.append({
            'filename': filename,
            'mode': mode,
            'hypothesis': hypothesis,
            'json': str(out_json),
            'zip': str(out_zip),
            'diff_count': len(diffs),
            'relation_delta': summary['relations'] - base_summary['relations'],
            'errors': len(errors),
            'relations': summary['relations'],
            'entities': summary['entities'],
        })
        if errors:
            err_path = REPORT_DIR / f'{filename}_validation_errors.txt'
            err_path.write_text('\n'.join(errors[:200]), encoding='utf-8')

    with DIFF_CSV.open('w', encoding='utf-8', newline='') as f:
        fieldnames = ['variant','sample_idx','action','type_before','type_after','relation_before','relation_after','reason','text_excerpt']
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(all_diffs)

    md = []
    md.append('# v46 第一批原子候选执行报告\n')
    md.append('本报告由 `脚本工具/make_v46_atomic_candidates.py` 自动生成。所有候选均以 `submit_v44_del_var_con_cross.json` 为底座，目标是执行已拍板的“离线大召回、线上小提交”策略。\n')
    md.append('## 1. 底座统计\n')
    md.append('|项目|数值|\n|---|---:|')
    md.append(f"|样本数|{base_summary['items']}|")
    md.append(f"|实体数|{base_summary['entities']}|")
    md.append(f"|关系数|{base_summary['relations']}|")
    md.append(f"|无关系样本数|{base_summary['empty_rel_items']}|")
    md.append(f"|关系类型数|{base_summary['types']}|\n")
    md.append('## 2. 候选文件清单\n')
    md.append('|建议提交顺序|候选|关系变化|修改条数|校验错误|提交 zip|假设|')
    md.append('|---:|---|---:|---:|---:|---|---|')
    for i, row in enumerate(report_rows, 1):
        zip_name = Path(row['zip']).name
        md.append(f"|{i}|`{row['filename']}`|{row['relation_delta']}|{row['diff_count']}|{row['errors']}|`数据/A榜/v46_atomic/{zip_name}`|{row['hypothesis']}|")
    md.append('\n## 3. 差异明细\n')
    md.append('完整差异已保存到 `分析报告/v46_atomic_diff_20260430.csv`。下表列出全部原子修改，便于提交前复核。\n')
    md.append('|候选|样本idx|动作|修改前类型|修改后类型|修改前关系|修改后关系|')
    md.append('|---|---:|---|---|---|---|---|')
    for d in all_diffs:
        md.append(f"|`{d['variant']}`|{d['sample_idx']}|{d['action']}|{d['type_before']}|{d['type_after']}|{d['relation_before']}|{d['relation_after']}|")
    md.append('\n## 4. 执行纪律\n')
    md.append('第一轮只建议提交前四个单假设候选。组合候选 `submit_v46_combo_gene_loi_mrk_del_cluster372` 只应在 `GENE-LOI-MRK` 删除版和样本 372 删除版均确认涨分后提交。`VAR-OCI-GST` 双条删除属于观察候选，优先级低于方向纠错和两个样本簇消融。\n')
    md.append('每次提交后必须把分数写入提交账本，并根据实际涨跌决定下一步，不应一次性上传多个候选导致因果不可归因。\n')
    REPORT_MD.write_text('\n'.join(md) + '\n', encoding='utf-8')

    print('wrote candidates:', OUT_DIR)
    print('wrote diff:', DIFF_CSV)
    print('wrote report:', REPORT_MD)
    for row in report_rows:
        print(row['filename'], 'delta', row['relation_delta'], 'diffs', row['diff_count'], 'errors', row['errors'])


if __name__ == '__main__':
    main()
